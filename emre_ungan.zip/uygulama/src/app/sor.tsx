// src/app/sor.tsx
import { useState } from 'react';
import { View, Text, TextInput, Pressable } from 'react-native';

export default function Sor() {
  const [soru, setSoru] = useState('');
  const [cevap, setCevap] = useState('');
  const [bekliyor, setBekliyor] = useState(false);

  async function gonder() {
    setBekliyor(true);
    try {
      const res = await fetch('/api/sor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ soru }),
      });
      const veri = await res.json();
      setCevap(veri.cevap ?? veri.hata);
    } catch {
      setCevap('Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edip tekrar deneyin.');
    } finally {
      setBekliyor(false);
    }
  }

  return (
    <View style={{ flex: 1, padding: 24, gap: 12 }}>
      <TextInput value={soru} onChangeText={setSoru} placeholder="Sorunuzu yazın"
        style={{ borderWidth: 1, borderRadius: 8, padding: 12 }} />
      <Pressable onPress={gonder} disabled={bekliyor}>
        <Text>{bekliyor ? 'Yanıt bekleniyor…' : 'Gönder'}</Text>
      </Pressable>
      <Text>{cevap}</Text>
    </View>
  );
}
