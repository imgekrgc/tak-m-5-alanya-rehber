// src/app/rota.tsx  (İlgi alanı ve süreye göre rota)
import { useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import veri from '../data/veri.json';
import { stil } from '../lib/tema';

const ilgiAlanlari = Array.from(new Set(veri.mekanlar.map((m) => m.tur)));
const sureler = ['Yarım gün', 'Bir gün'];

export default function Rota() {
  const [ilgi, setIlgi] = useState('');
  const [sure, setSure] = useState('');
  const [rota, setRota] = useState('');
  const [bekliyor, setBekliyor] = useState(false);

  async function olustur() {
    setBekliyor(true);
    setRota('');
    try {
      const soru = `${sure} için ${ilgi} ilgi alanına göre rota öner`;
      const res = await fetch('/api/sor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ soru }),
      });
      const v = await res.json();
      setRota(v.cevap ?? v.hata);
    } catch {
      setRota('Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edip tekrar deneyin.');
    } finally {
      setBekliyor(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={stil.sayfa}>
      <Text style={stil.baslik}>Günlük rota</Text>
      <Text style={stil.soluk}>İlgi alanı</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {ilgiAlanlari.map((a) => (
          <Pressable key={a} onPress={() => setIlgi(a)} style={[stil.secenek, ilgi === a && stil.secili]}>
            <Text style={stil.metin}>{a}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={stil.soluk}>Süre</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        {sureler.map((s) => (
          <Pressable key={s} onPress={() => setSure(s)} style={[stil.secenek, sure === s && stil.secili]}>
            <Text style={stil.metin}>{s}</Text>
          </Pressable>
        ))}
      </View>
      <Pressable onPress={olustur} disabled={bekliyor || !ilgi || !sure} style={[stil.dugme, (!ilgi || !sure) && { opacity: 0.5 }]}>
        <Text style={stil.dugmeYazi}>{bekliyor ? 'Rota hazırlanıyor…' : 'Rota oluştur'}</Text>
      </Pressable>
      <Text style={stil.metin}>{rota}</Text>
    </ScrollView>
  );
}
