// src/app/yorum-panosu.tsx  (Otel işletmecisi: olumsuz yorumların özeti)
import { useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import veri from '../data/veri.json';
import { stil } from '../lib/tema';
import { onayIste } from '../lib/onay';

type Sonuc = { duygu: string; konular: string[] };
const ILK_N = 10; // Gemini ücretsiz limitleri için bir seferde en fazla 10 yorum

function ayristir(cevap: string): Sonuc {
  try {
    return JSON.parse(cevap);
  } catch {
    return { duygu: 'bilinmiyor', konular: [] }; // ayrıştırılamadı: say ve kaydet
  }
}

export default function YorumPanosu() {
  const [yorumlar, setYorumlar] = useState(veri.yorumlar);
  const [sonuclar, setSonuclar] = useState<Record<string, Sonuc>>({});
  const [bekliyor, setBekliyor] = useState(false);
  const [ayrisamayan, setAyrisamayan] = useState(0);
  const [hata, setHata] = useState('');

  async function ozetle() {
    setBekliyor(true);
    setHata('');
    const yeni: Record<string, Sonuc> = { ...sonuclar };
    let bozuk = 0;
    for (const y of yorumlar.slice(0, ILK_N)) {
      if (yeni[y.id]) continue;
      try {
        const res = await fetch('/api/yorum', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ yorum: y.metin }),
        });
        const v = await res.json();
        if (!v.cevap) { setHata(v.hata ?? 'Beklenmeyen hata'); break; }
        const s = ayristir(v.cevap);
        if (s.duygu === 'bilinmiyor') bozuk++;
        yeni[y.id] = s;
      } catch {
        setHata('Sunucuya ulaşılamadı. Biraz sonra tekrar deneyin.');
        break;
      }
    }
    setSonuclar(yeni);
    setAyrisamayan((n) => n + bozuk);
    setBekliyor(false);
  }

  const olumsuz = yorumlar.filter((y) => sonuclar[y.id]?.duygu === 'olumsuz');
  const konuSayilari: Record<string, number> = {};
  olumsuz.forEach((y) => sonuclar[y.id].konular.forEach((k) => (konuSayilari[k] = (konuSayilari[k] ?? 0) + 1)));

  return (
    <ScrollView contentContainerStyle={stil.sayfa}>
      <Text style={stil.baslik}>Yorum panosu</Text>
      <Pressable onPress={ozetle} disabled={bekliyor} style={stil.dugme}>
        <Text style={stil.dugmeYazi}>{bekliyor ? 'Yorumlar sınıflandırılıyor…' : 'Olumsuz yorumları özetle'}</Text>
      </Pressable>
      {!!hata && <Text style={{ color: '#B3261E' }}>{hata}</Text>}

      {Object.keys(sonuclar).length > 0 && (
        <View style={stil.kart}>
          <Text style={stil.metin}>Olumsuz yorum: {olumsuz.length}</Text>
          {Object.entries(konuSayilari).map(([k, n]) => (
            <Text key={k} style={stil.soluk}>{k}: {n}</Text>
          ))}
          {ayrisamayan > 0 && <Text style={stil.soluk}>Ayrıştırılamayan yanıt: {ayrisamayan}</Text>}
        </View>
      )}

      {yorumlar.map((y) => (
        <View key={y.id} style={stil.kart}>
          <Text style={stil.metin}>{y.metin}</Text>
          {sonuclar[y.id] && (
            <Text style={stil.soluk}>{sonuclar[y.id].duygu} · {sonuclar[y.id].konular.join(', ')}</Text>
          )}
          <Pressable
            onPress={() =>
              onayIste('Bu yorum panodan kaldırılsın mı?', () =>
                setYorumlar((l) => l.filter((x) => x.id !== y.id)))
            }>
            <Text style={{ color: '#B3261E' }}>Yorumu kaldır</Text>
          </Pressable>
        </View>
      ))}
    </ScrollView>
  );
}
