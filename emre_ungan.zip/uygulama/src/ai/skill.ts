// src/ai/skill.ts  (ilk talimat; 12. haftada SKILL.md gövdesiyle değişecek)
export const SKILL = `
# Görev
Rota ve mekan sorularını yalnızca mekan kartlarına dayanarak yanıtla; yorum sınıflandırmasında yalnızca JSON döndür.
`;
