// src/lib/tema.ts
import { StyleSheet } from 'react-native';

export const renk = {
  zemin: '#F7F3EC',
  deniz: '#0E6E7E',
  denizAcik: '#D9EEF1',
  yazi: '#1D2B2F',
  soluk: '#5C6B70',
  uyari: '#B3261E',
};

export const stil = StyleSheet.create({
  sayfa: { flex: 1, padding: 24, gap: 12, backgroundColor: renk.zemin },
  baslik: { fontSize: 24, fontWeight: '600', color: renk.yazi },
  metin: { fontSize: 16, lineHeight: 24, color: renk.yazi },
  soluk: { fontSize: 14, color: renk.soluk },
  kart: { padding: 14, borderRadius: 10, backgroundColor: '#fff', gap: 4 },
  dugme: { padding: 12, borderRadius: 8, backgroundColor: renk.deniz, alignItems: 'center' },
  dugmeYazi: { color: '#fff', fontWeight: '600' },
  secili: { backgroundColor: renk.denizAcik, borderColor: renk.deniz },
  secenek: { padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#C9D3D5' },
});
