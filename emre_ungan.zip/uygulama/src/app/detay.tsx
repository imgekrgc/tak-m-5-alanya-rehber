// src/app/detay.tsx  (Mekan detayı + Benzer öneriler)
import { ScrollView, Text, View } from 'react-native';
import { Link, useLocalSearchParams } from 'expo-router';
import veri from '../data/veri.json';
import benzerler from '../data/benzerler.json';
import { stil } from '../lib/tema';

const kayitlar = veri.mekanlar;

export default function Detay() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const kayit = kayitlar.find((k) => k.id === id);

  if (!kayit) {
    return (
      <View style={stil.sayfa}>
        <Text style={stil.metin}>Mekan bulunamadı. Mekanlar listesinden yeniden seçin.</Text>
        <Link href="/mekanlar" style={stil.metin}>Mekanlara dön</Link>
      </View>
    );
  }

  const benzerIdler: string[] = (benzerler as Record<string, string[]>)[kayit.id] ?? [];
  const benzerKayitlar = kayitlar.filter((k) => benzerIdler.includes(k.id));

  return (
    <ScrollView contentContainerStyle={stil.sayfa}>
      <Text style={stil.baslik}>{kayit.ad}</Text>
      <Text style={stil.soluk}>{kayit.tur}</Text>
      <Text style={stil.metin}>{kayit.metin}</Text>
      <Text style={stil.soluk}>Kaynak: {kayit.kaynak}</Text>

      <Text style={[stil.baslik, { fontSize: 18, marginTop: 16 }]}>Benzer öneriler</Text>
      {benzerKayitlar.length === 0 && (
        <Text style={stil.soluk}>Bu mekan için benzer öneri yok.</Text>
      )}
      {benzerKayitlar.map((b) => (
        <Link key={b.id} href={{ pathname: '/detay', params: { id: b.id } }}>
          <View style={stil.kart}>
            <Text style={stil.metin}>{b.ad}</Text>
            <Text style={stil.soluk}>{b.tur}</Text>
          </View>
        </Link>
      ))}
    </ScrollView>
  );
}
