// src/app/mekanlar.tsx
import { FlatList, Text, View } from 'react-native';
import { Link } from 'expo-router';
import veri from '../data/veri.json';
import { stil } from '../lib/tema';

export default function Mekanlar() {
  return (
    <View style={stil.sayfa}>
      <Text style={stil.baslik}>Mekanlar</Text>
      <FlatList
        data={veri.mekanlar}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ gap: 10 }}
        ListEmptyComponent={<Text style={stil.soluk}>Henüz mekan yok. veri.json dosyasına kayıt ekleyin.</Text>}
        renderItem={({ item }) => (
          <Link href={{ pathname: '/detay', params: { id: item.id } }}>
            <View style={stil.kart}>
              <Text style={stil.metin}>{item.ad}</Text>
              <Text style={stil.soluk}>{item.tur}</Text>
            </View>
          </Link>
        )}
      />
    </View>
  );
}
