# Yunus Emre Unğan – dosyalar
Bu klasördeki dosyalar `uygulama/` içine aynı yollarla kopyalanır.
- Önce: `npm install @google/genai`
- `app.json`: `"expo": { "web": { "output": "server" } }`
- `assets/maskot.png` ve `src/data/*.json` YER TUTUCUDUR (Asrın / Hüseyin / Oktay gerçeğini koyacak).
- Her değişiklik ayrı dalda + pull request ile (Adım 10.4). `.env` repoya girmez.
