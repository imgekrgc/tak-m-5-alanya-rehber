// src/app/index.tsx  (Ana sayfa)
import { View, Text } from 'react-native';
import { Link } from 'expo-router';
import Maskot from '../components/Maskot';
import { stil } from '../lib/tema';

export default function Ana() {
  return (
    <View style={stil.sayfa}>
      <Maskot />
      <Text style={stil.baslik}>Alanya Rehber</Text>
      <Text style={stil.metin}>Alanya'da bir günü planlayın; otel yorumlarını özetleyin.</Text>
      <Link href="/mekanlar" style={stil.metin}>Mekanlar</Link>
      <Link href="/rota" style={stil.metin}>Günlük rota oluştur</Link>
      <Link href="/yorum-panosu" style={stil.metin}>Yorum panosu</Link>
      <Link href="/sor" style={stil.metin}>AI asistanına sor</Link>
      <Text style={stil.soluk}>Ders projesidir; tüm veriler sentetiktir.</Text>
    </View>
  );
}
