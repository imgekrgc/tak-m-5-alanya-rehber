// src/app/api/yorum+api.ts
import { GoogleGenAI } from '@google/genai';
import { SKILL } from '../../ai/skill';
import veri from '../../data/veri.json';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function POST(request: Request) {
  const { yorum } = await request.json();
  if (!yorum || yorum.length > 2000) {
    return Response.json({ hata: 'Geçersiz yorum' }, { status: 400 });
  }

  try {
    const interaction = await ai.interactions.create({
      model: 'gemini-3.8-flash',
      input: `${SKILL}\n\nGörev: Aşağıdaki yorumu sınıflandır ve yalnızca JSON döndür.\nYorum: ${yorum}`,
    });
    return Response.json({ cevap: interaction.output_text });
  } catch (e) {
    return Response.json(
      { hata: 'AI şu an yanıt veremiyor; biraz sonra tekrar deneyin.' },
      { status: 503 }
    );
  }
}
