// src/components/Maskot.tsx
import { useEffect, useRef } from 'react';
import { Animated } from 'react-native';

export default function Maskot() {
  const opaklik = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(opaklik, { toValue: 1, duration: 800, useNativeDriver: true }).start();
  }, []);
  return (
    <Animated.Image
      source={require('../../assets/maskot.png')}
      style={{ width: 120, height: 120, opacity: opaklik }}
    />
  );
}
