// src/lib/onay.ts
import { Alert, Platform } from 'react-native';

export function onayIste(mesaj: string, onay: () => void) {
  if (Platform.OS === 'web') {
    if (window.confirm(mesaj)) onay();
    return;
  }
  Alert.alert('Onay', mesaj, [
    { text: 'Vazgeç', style: 'cancel' },
    { text: 'Evet', onPress: onay },
  ]);
}
